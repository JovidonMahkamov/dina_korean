import '../model/profile_model.dart';

abstract class ProfileRemoteDataSource{
  Future<ProfileModel> getProfile();
  Future<void> putProfileEdit(ProfileModel profile);
}