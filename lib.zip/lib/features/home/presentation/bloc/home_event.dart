
abstract class HomeEvent {
  const HomeEvent();
}
class Statistic extends HomeEvent {

  const Statistic();
}


