abstract class ResultEvent{
  ResultEvent();
}
class ResultE extends ResultEvent {

   ResultE();
}