class LogInUser {
  final String token;
  final String role;
  final int id;

  LogInUser({required this.token, required this.role,required this.id});
}
