import 'package:dina_korean_real/features/online_lessons/domain/entities/course_entity.dart';
import 'package:dina_korean_real/features/online_lessons/domain/repository/course_repo.dart';
import '../datasource/course_remote_data_source.dart';

class CourseRepoImpl implements CourseRepo {
  final CourseRemoteDataSource courseRemoteDataSource;

  CourseRepoImpl({required this.courseRemoteDataSource});

  @override
  Future<List<CourseEntity>> getCourse() {
    return courseRemoteDataSource.getCourse();
  }
}
