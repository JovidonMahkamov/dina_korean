import 'package:dina_korean_real/features/online_lessons/data/model/course_model.dart';

abstract class CourseRemoteDataSource{
  Future <List<CourseModel>> getCourse();
}