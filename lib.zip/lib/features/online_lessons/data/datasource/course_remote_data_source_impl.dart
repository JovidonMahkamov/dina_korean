import 'package:dina_korean_real/core/network/dio_client.dart';
import 'package:dina_korean_real/features/online_lessons/data/datasource/course_remote_data_source.dart';
import 'package:dina_korean_real/features/online_lessons/data/model/course_model.dart';

import '../../../../core/network/api_urls.dart';
import '../../../../core/untils/logger.dart';

class CourseRemoteDataSourceImpl implements CourseRemoteDataSource{
  final DioClient dioClient = DioClient();

  @override
  Future<List<CourseModel>> getCourse()async {
    try {
      final response = await dioClient.get(ApiUrls.onlineCourses);
      if (response.statusCode == 200 || response.statusCode == 201) {
        LoggerService.info('course successful: ${response.data}');
        return (response.data as List)
            .map((e) => CourseModel.fromJson(e as Map<String, dynamic>))
            .toList();
      } else {
        LoggerService.warning("course failed:${response.statusCode}");
        throw Exception('course failed: ${response.statusCode}');
      }
    } catch (e) {
      LoggerService.error('Error during user course: $e');
      rethrow;
    }
  }

}