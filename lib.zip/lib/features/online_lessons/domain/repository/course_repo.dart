import 'package:dina_korean_real/features/online_lessons/domain/entities/course_entity.dart';

abstract class CourseRepo{
  Future<List<CourseEntity>> getCourse();
}