import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../auth/presentation/widgets/text_field_widget.dart';
import '../../widget/audio_player_widget.dart';
import '../../widget/video_player_widget.dart';

class OnlineLessonDetails extends StatefulWidget {
  const OnlineLessonDetails({super.key});

  @override
  State<OnlineLessonDetails> createState() => _OnlineLessonDetailsState();
}

class _OnlineLessonDetailsState extends State<OnlineLessonDetails> {
  TextEditingController textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder:
              (context) => IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                },
              ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Profil',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(leading: Icon(Icons.person), title: Text('Profilim')),
            ListTile(leading: Icon(Icons.settings), title: Text('Sozlamalar')),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const VideoPlayerWidget(videoPath: 'assets/video/lola.mp4'),
              SizedBox(height: 20.h),
              Text(
                '1- Dars',
                style: TextStyle(fontSize: 24.sp, fontWeight: FontWeight.w800),
              ),
              Divider(),
              Text(
                "Darsga oid lug'atlar",
                style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 25.h),
              Row(
                children: [
                  Icon(Icons.verified_outlined, color: Colors.blueAccent),
                  SizedBox(width: 15.w),
                  Text('Harflarni yodlang !'),
                ],
              ),
              AudioPlayerWidget(),
              SizedBox(height: 100.h),
              Divider(),
              Text(
                "Darsga oid mashqlar",
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15.sp),
              ),
              SizedBox(height: 20.h),
              Image.asset('assets/online_lessons/Dina_4.png'),
              SizedBox(height: 15.h,),
              Text(
                "1-Savol: Quyidagi rasmdagi harfni o'zbek tilidagi ifodasi qanday ?",
              ),
              SizedBox(height: 20.h),
              TextFieldWidget(text: 'Javob UZ/KR', obscureText: false,),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text('Tekshirish'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
