abstract class CourseEvent{
  CourseEvent();
}
class CourseE extends CourseEvent {

  CourseE();
}